from django.http import HttpResponse
from django.shortcuts import render
import string


def home_view(request):
    #return HttpResponse("welcome to my home page")
    info = {'name':'harsh','age':28,'qual':'BE'}
    return render(request,'index.html',info)

def about_view(request):
    #return HttpResponse("this is about page")
    return render(request,'about.html')



def analyze_func(request):
    input_text = request.POST.get('floatingTextarea')
    make_upper = request.POST.get('r1','off')
    word_count = request.POST.get('r2','off')
    White_Space_Remover = request.POST.get('r5','off')
    remove_punctuation = request.POST.get('r3','off')
    new_line_remover = request.POST.get('r4','off')
    
    if make_upper =='on':
        result = input_text.upper()
        #return HttpResponse(result)
        result_data = {'inp':result}
        return render(request,'result.html',result_data)


    elif word_count == "on":
        count = 0
        for item in input_text:
            count+=1
            result_data = {'inp':count}
        return render(request,'result.html',result_data)

    elif White_Space_Remover == "on":
        data = input_text
        result = data.replace(' ','')
        result_data = {'inp':result}
        return render(request,'result.html',result_data)

    elif remove_punctuation == 'on':
        punctuations = string.punctuation
        final_data = ""
        for char in input_text:
            if char not in punctuations:
                final_data = final_data+char
        result_data = {'inp':final_data}
        return render(request,'result.html',result_data)

    elif new_line_remover == "on":
        res = input_text.splitlines()
        result = ' '.join(res)
        result_data = {'inp':result}
        return render(request,'result.html',result_data) 




